/**
 * Faroese translation for bootstrap-datetimepicker
 * René Bischoff <http://github.com/Fjandin>
 */
;(function($){
	$.fn.datetimepicker.dates['fo'] = {
		days: ["Sunnudagur", "Mánadagur", "Týsdagur", "Mikudagur", "Hósdagur", "Fríggjadagur", "Leygardagur", "Sunnudagur"],
		daysShort: ["Sun", "Mán", "Týs", "Mik", "Hós", "Frí", "Ley", "Sun"],
		daysMin: ["Su", "Má", "Tý", "Mi", "Hó", "Fr", "Le", "Su"],
		months: ["Januar", "Februar", "Mars", "Apríl", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember"],
		monthsShort: ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Des"],
		today: "Í dag"
	};
}(jQuery));